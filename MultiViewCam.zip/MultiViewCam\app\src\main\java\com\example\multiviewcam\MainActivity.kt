package com.example.multiviewcam

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.multiviewcam.camera.Camera2Controller
import com.example.multiviewcam.gl.MultiViewRenderer
import com.example.multiviewcam.gl.MultiViewSurfaceView
import com.example.multiviewcam.model.ViewSpec
import com.example.multiviewcam.recorder.VideoRecorder
import kotlin.math.ceil
import kotlin.math.sqrt

/**
 * Demo: una sola camara -> varias "camaras virtuales" recortadas/zoomeadas,
 * una ventana PiP arrastrable, cambio de lente y grabacion local a .mp4.
 *
 * Todo el trabajo pesado esta en MultiViewRenderer (GL) y VideoRecorder
 * (MediaCodec + MediaMuxer). Esta actividad solo orquesta.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
        private const val MAX_MAIN_VIEWS = 4
        private const val REC_WIDTH = 1280
        private const val REC_HEIGHT = 720
        private const val REC_FPS = 30
        private const val REC_BITRATE = 6_000_000
    }

    private lateinit var surfaceView: MultiViewSurfaceView
    private lateinit var tvRec: TextView
    private lateinit var btnAddView: Button
    private lateinit var btnPip: Button
    private lateinit var btnSwitch: Button
    private lateinit var btnRecord: Button

    private val renderer: MultiViewRenderer
        get() = surfaceView.mvRenderer

    private val camera = lazy { Camera2Controller(this) }
    private var recorder: VideoRecorder? = null

    private var pendingSurfaceTexture: SurfaceTexture? = null
    private var pendingBufferW = 1280
    private var pendingBufferH = 720
    private var cameraStarted = false

    private var pipEnabled = false

    private val uiHandler = Handler(Looper.getMainLooper())

    // ------------------------------------------------------------------
    // Ciclo de vida
    // ------------------------------------------------------------------

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasCameraPermission()) {
            startCameraIfNeeded()
        } else {
            Toast.makeText(this, R.string.msg_perm_required, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        surfaceView = findViewById(R.id.glView)
        tvRec = findViewById(R.id.tvRec)
        btnAddView = findViewById(R.id.btnAddView)
        btnPip = findViewById(R.id.btnPip)
        btnSwitch = findViewById(R.id.btnSwitch)
        btnRecord = findViewById(R.id.btnRecord)

        setupCamera()
        setupButtons()
        setupInitialViews()
    }

    override fun onResume() {
        super.onResume()
        surfaceView.onResume()
        if (hasCameraPermission()) {
            startCameraIfNeeded()
        }
    }

    override fun onPause() {
        if (recorder != null) {
            stopRecording()
        }
        camera.value.close()
        cameraStarted = false
        surfaceView.onPause()
        super.onPause()
    }

    // ------------------------------------------------------------------
    // Camara
    // ------------------------------------------------------------------

    private fun setupCamera() {
        renderer.listener = object : MultiViewRenderer.Listener {
            override fun onCameraSurfaceReady(
                surfaceTexture: SurfaceTexture,
                bufferWidth: Int,
                bufferHeight: Int
            ) {
                runOnUiThread {
                    handleSurfaceReady(surfaceTexture, bufferWidth, bufferHeight)
                }
            }
        }

        camera.value.callback = object : Camera2Controller.Callback {
            override fun onCameraReady(sensorOrientation: Int) {
                renderer.sensorOrientation = sensorOrientation
                Log.i(TAG, "Camara lista, sensor=$sensorOrientation")
            }

            override fun onCameraError(message: String) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun handleSurfaceReady(st: SurfaceTexture, w: Int, h: Int) {
        pendingSurfaceTexture = st
        pendingBufferW = w
        pendingBufferH = h

        if (hasCameraPermission()) {
            startCameraIfNeeded()
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }

    private fun startCameraIfNeeded() {
        if (cameraStarted) return
        val st = pendingSurfaceTexture ?: return
        cameraStarted = true
        camera.value.open(st, pendingBufferW, pendingBufferH)
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------
    // Botones
    // ------------------------------------------------------------------

    private fun setupButtons() {
        btnAddView.setOnClickListener { addVirtualView() }
        btnPip.setOnClickListener { togglePip() }
        btnSwitch.setOnClickListener {
            camera.value.switchCamera()
            Toast.makeText(this, R.string.msg_switching, Toast.LENGTH_SHORT).show()
        }
        btnRecord.setOnClickListener {
            if (recorder == null) startRecording() else stopRecording()
        }
    }

    // ------------------------------------------------------------------
    // Multiples vistas
    // ------------------------------------------------------------------

    private fun setupInitialViews() {
        val spec = ViewSpec(renderer.nextId(), RectF(), RectF(0f, 0f, 1f, 1f))
        spec.resetCrop()
        renderer.addView(spec)
        layoutMainViews()
    }

    private fun addVirtualView() {
        val mainViews = renderer.views.filter { !it.isPip }

        if (mainViews.size >= MAX_MAIN_VIEWS) {
            Toast.makeText(
                this,
                getString(R.string.msg_max_views, MAX_MAIN_VIEWS),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val spec = ViewSpec(renderer.nextId(), RectF(), RectF(0f, 0f, 1f, 1f))
        applyPresetCrop(spec, mainViews.size)
        renderer.addView(spec)
        layoutMainViews()
    }

    /** Cada vista muestra una zona distinta del mismo frame: simula multi-camara. */
    private fun applyPresetCrop(spec: ViewSpec, index: Int) {
        when (index) {
            0 -> spec.resetCrop()
            1 -> spec.applyZoom(2.0f, 0.5f, 0.5f)
            2 -> spec.applyZoom(2.5f, 0.30f, 0.35f)
            else -> spec.applyZoom(3.0f, 0.70f, 0.60f)
        }
    }

    /**
     * Reparte las vistas principales en una rejilla.
     * Coordenadas NDC top-down: (-1,-1) arriba-izquierda, (1,1) abajo-derecha.
     */
    private fun layoutMainViews() {
        val list = renderer.views.filter { !it.isPip }
        val n = list.size
        if (n == 0) return

        val cols = ceil(sqrt(n.toDouble())).toInt().coerceAtLeast(1)
        val rows = ceil(n.toDouble() / cols).toInt().coerceAtLeast(1)

        val cellW = 2f / cols
        val cellH = 2f / rows
        val gap = 0.012f

        list.forEachIndexed { i, view ->
            val c = i % cols
            val r = i / cols

            val left = -1f + c * cellW + gap
            val right = -1f + (c + 1) * cellW - gap
            val top = -1f + r * cellH + gap
            val bottom = -1f + (r + 1) * cellH - gap

            view.dest.set(left, top, right, bottom)
        }
    }

    // ------------------------------------------------------------------
    // PiP
    // ------------------------------------------------------------------

    private fun togglePip() {
        if (pipEnabled) {
            renderer.views.firstOrNull { it.isPip }?.let { renderer.removeView(it) }
            pipEnabled = false
            btnPip.setText(R.string.btn_pip)
            return
        }

        val spec = ViewSpec(
            id = renderer.nextId(),
            dest = RectF(-0.92f, 0.42f, -0.20f, 0.94f),
            crop = RectF(0f, 0f, 1f, 1f),
            isPip = true
        )
        spec.applyZoom(2.2f, 0.5f, 0.40f)
        renderer.addView(spec)
        pipEnabled = true
        btnPip.setText(R.string.btn_pip_off)
        Toast.makeText(this, R.string.msg_pip_hint, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // Grabacion
    // ------------------------------------------------------------------

    private fun startRecording() {
        if (recorder != null) return

        try {
            val rec = VideoRecorder(
                context = this,
                width = REC_WIDTH,
                height = REC_HEIGHT,
                frameRate = REC_FPS,
                bitRate = REC_BITRATE
            )
            val surface = rec.start()
            recorder = rec

            renderer.startRecording(surface, REC_WIDTH, REC_HEIGHT)

            tvRec.visibility = View.VISIBLE
            btnRecord.setText(R.string.btn_stop)
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar la grabacion", e)
            try {
                recorder?.stop()
            } catch (ignored: Exception) {
                // nada
            }
            recorder = null
            renderer.stopRecording()
            tvRec.visibility = View.GONE
            btnRecord.setText(R.string.btn_record)
            Toast.makeText(this, R.string.msg_record_error, Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        val rec = recorder ?: return
        recorder = null

        // El renderer deja de copiar al encoder en el siguiente frame.
        renderer.stopRecording()

        // Damos margen para que el ultimo frame llegue al encoder antes
        // de cerrar el muxer.
        uiHandler.postDelayed({
            try {
                rec.stop()
            } catch (e: Exception) {
                Log.e(TAG, "Error cerrando la grabacion", e)
            }

            tvRec.visibility = View.GONE
            btnRecord.setText(R.string.btn_record)

            Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_LONG).show()
        }, 200)
    }
}
