package com.example.multiviewcam.gl

import android.content.Context
import android.opengl.GLES20
import java.nio.FloatBuffer

/**
 * Envoltorio minimo de un programa GLSL.
 *
 * Tolera que algunos atributos/uniformes no existan en el shader
 * (glGetAttribLocation devuelve -1), cosa que ocurre con el shader
 * de color plano.
 */
class GlProgram(context: Context, vertexRes: Int, fragmentRes: Int) {

    val id: Int
    val aPosition: Int
    val aTexCoord: Int
    val uMVP: Int
    val uTexMatrix: Int
    val uTexture: Int
    val uColor: Int

    init {
        val vertexSource = GlUtils.readRawText(context, vertexRes)
        val fragmentSource = GlUtils.readRawText(context, fragmentRes)
        id = GlUtils.createProgram(vertexSource, fragmentSource)

        aPosition = GLES20.glGetAttribLocation(id, "aPosition")
        aTexCoord = GLES20.glGetAttribLocation(id, "aTexCoord")
        uMVP = GLES20.glGetUniformLocation(id, "uMVP")
        uTexMatrix = GLES20.glGetUniformLocation(id, "uTexMatrix")
        uTexture = GLES20.glGetUniformLocation(id, "sTexture")
        uColor = GLES20.glGetUniformLocation(id, "uColor")
    }

    fun use() {
        GLES20.glUseProgram(id)
    }

    /** Activa y enlaza los atributos disponibles. */
    fun bindAttributes(position: FloatBuffer, texCoord: FloatBuffer?) {
        if (aPosition >= 0) {
            position.position(0)
            GLES20.glEnableVertexAttribArray(aPosition)
            GLES20.glVertexAttribPointer(
                aPosition, 2, GLES20.GL_FLOAT, false, 0, position
            )
        }
        if (aTexCoord >= 0 && texCoord != null) {
            texCoord.position(0)
            GLES20.glEnableVertexAttribArray(aTexCoord)
            GLES20.glVertexAttribPointer(
                aTexCoord, 2, GLES20.GL_FLOAT, false, 0, texCoord
            )
        }
    }

    fun release() {
        GLES20.glDeleteProgram(id)
    }
}
