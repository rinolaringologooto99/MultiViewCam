package com.example.multiviewcam.recorder

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Grabador local: MediaCodec (H.264) -> MediaMuxer -> .mp4.
 *
 * El encoder usa COLOR_FormatSurface, por lo que no recibe buffers de
 * bytes sino una Surface de entrada. Esa Surface la alimenta el
 * EncoderBlitter del renderer.
 *
 * Limitacion conocida: la pista es SOLO video (sin audio). Anadir audio
 * requiere un AudioRecord + un MediaCodec AAC y mezclar dos pistas; se
 * documenta en el README como siguiente paso.
 */
class VideoRecorder(
    private val context: Context,
    private val width: Int,
    private val height: Int,
    private val frameRate: Int = 30,
    private val bitRate: Int = 6_000_000
) {

    companion object {
        private const val TAG = "VideoRecorder"
        private const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val TIMEOUT_US = 10_000L
    }

    private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null

    private var trackIndex = -1

    @Volatile
    private var muxerStarted = false

    @Volatile
    private var abort = false

    private var drainThread: Thread? = null

    private var pfd: ParcelFileDescriptor? = null
    private var outputUri: Uri? = null
    private var outputFile: File? = null

    val isRecording: Boolean
        get() = codec != null

    /**
     * Configura el encoder y devuelve la Surface de entrada.
     * Lanza [IOException] si el dispositivo no puede crear el archivo.
     */
    fun start(): Surface {
        check(codec == null) { "Ya hay una grabacion en curso" }

        val fileName = "MVC_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"

        // El muxer se crea antes del codec para fallar rapido si no hay
        // sitio donde escribir.
        muxer = createMuxer(fileName)

        val format = MediaFormat.createVideoFormat(MIME, width, height).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(
                MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
            )
        }

        val encoder = MediaCodec.createEncoderByType(MIME)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)

        val surface = encoder.createInputSurface()
        encoder.start()

        codec = encoder
        inputSurface = surface
        abort = false
        trackIndex = -1
        muxerStarted = false

        drainThread = Thread({ drainLoop() }, "MVC-Drain").also {
            it.priority = Thread.NORM_PRIORITY + 1
            it.start()
        }

        Log.i(TAG, "Encoder iniciado ${width}x$height @$frameRate fps, $bitRate bps")
        return surface
    }

    /**
     * Cierra la grabacion. Devuelve la Uri del video en MediaStore
     * (API 29+) o null si se guardo como archivo privado.
     */
    fun stop(): Uri? {
        val encoder = codec ?: return outputUri

        try {
            encoder.signalEndOfInputStream()
        } catch (e: Exception) {
            Log.w(TAG, "signalEndOfInputStream: ${e.message}")
        }

        val t = drainThread
        if (t != null) {
            try {
                t.join(3000)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
            if (t.isAlive) {
                Log.w(TAG, "El hilo de drenado no termino; se aborta")
                abort = true
                try {
                    t.join(1000)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        }
        drainThread = null

        try {
            encoder.stop()
        } catch (e: Exception) {
            Log.w(TAG, "encoder.stop: ${e.message}")
        }
        try {
            encoder.release()
        } catch (e: Exception) {
            Log.w(TAG, "encoder.release: ${e.message}")
        }
        codec = null

        try {
            if (muxerStarted) muxer?.stop()
        } catch (e: Exception) {
            Log.e(TAG, "muxer.stop: ${e.message}")
        }
        try {
            muxer?.release()
        } catch (e: Exception) {
            Log.w(TAG, "muxer.release: ${e.message}")
        }
        muxer = null
        muxerStarted = false

        try {
            inputSurface?.release()
        } catch (e: Exception) {
            // ignorado
        }
        inputSurface = null

        try {
            pfd?.close()
        } catch (e: Exception) {
            // ignorado
        }
        pfd = null

        Log.i(TAG, "Grabacion finalizada")
        return outputUri
    }

    // ------------------------------------------------------------------
    // Drenado del encoder
    // ------------------------------------------------------------------

    private fun drainLoop() {
        val encoder = codec ?: return
        val info = MediaCodec.BufferInfo()
        var sawEos = false

        while (!sawEos && !abort) {
            val index = try {
                encoder.dequeueOutputBuffer(info, TIMEOUT_US)
            } catch (e: IllegalStateException) {
                Log.w(TAG, "dequeueOutputBuffer: ${e.message}")
                break
            }

            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    // sin datos todavia
                }

                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        val m = muxer ?: break
                        try {
                            trackIndex = m.addTrack(encoder.outputFormat)
                            m.start()
                            muxerStarted = true
                            Log.i(TAG, "Muxer iniciado (pista $trackIndex)")
                        } catch (e: Exception) {
                            Log.e(TAG, "addTrack/start: ${e.message}")
                            break
                        }
                    }
                }

                index >= 0 -> {
                    val buffer = try {
                        encoder.getOutputBuffer(index)
                    } catch (e: Exception) {
                        null
                    }

                    if (buffer != null) {
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            // Los parametros SPS/PPS ya los escribio el muxer.
                            info.size = 0
                        }
                        if (info.size > 0 && muxerStarted) {
                            try {
                                buffer.position(info.offset)
                                buffer.limit(info.offset + info.size)
                                muxer?.writeSampleData(trackIndex, buffer, info)
                            } catch (e: Exception) {
                                Log.e(TAG, "writeSampleData: ${e.message}")
                            }
                        }
                        encoder.releaseOutputBuffer(index, false)

                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            sawEos = true
                        }
                    }
                }
            }
        }

        Log.i(TAG, "Hilo de drenado terminado")
    }

    // ------------------------------------------------------------------
    // Destino del archivo
    // ------------------------------------------------------------------

    private fun createMuxer(fileName: String): MediaMuxer {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            createMuxerMediaStore(fileName)
        } else {
            createMuxerFile(fileName)
        }
    }

    /** API 29+: Movies/MultiViewCam via MediaStore (sin permisos). */
    private fun createMuxerMediaStore(fileName: String): MediaMuxer {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/MultiViewCam"
            )
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("No se pudo crear el archivo en MediaStore")

        outputUri = uri

        val descriptor = resolver.openFileDescriptor(uri, "w")
            ?: throw IOException("No se pudo abrir el descriptor de salida")

        pfd = descriptor
        return MediaMuxer(descriptor.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    }

    /** API 24-28: carpeta privada de la app. */
    private fun createMuxerFile(fileName: String): MediaMuxer {
        val base = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: context.filesDir

        val dir = File(base, "MultiViewCam")
        if (!dir.exists() && !dir.mkdirs()) {
            throw IOException("No se pudo crear la carpeta ${dir.absolutePath}")
        }

        val file = File(dir, fileName)
        outputFile = file
        Log.i(TAG, "Guardando en ${file.absolutePath}")

        return MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    }

    /** Ruta legible del ultimo archivo grabado, para mensajes al usuario. */
    fun lastOutputPath(): String? = outputUri?.toString() ?: outputFile?.absolutePath
}
