package com.example.multiviewcam.gl

import android.content.Context
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import android.view.Surface
import com.example.multiviewcam.R
import com.example.multiviewcam.model.ViewSpec
import java.nio.FloatBuffer
import java.util.concurrent.CopyOnWriteArrayList
import javax.microedition.khronos.egl.EGLConfig as JEGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Renderiza N vistas virtuales a partir de un unico SurfaceTexture de camara.
 *
 * Modos de salida:
 *   1. Preview: se dibuja al framebuffer por defecto de la GLSurfaceView.
 *   2. Grabacion: se dibuja a un FBO intermedio y luego el EncoderBlitter
 *      copia esa textura a la Surface del MediaCodec, usando un contexto
 *      EGL secundario compartido.
 */
class MultiViewRenderer(private val context: Context) :
    GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    companion object {
        private const val TAG = "MultiViewRenderer"
    }

    interface Listener {
        fun onCameraSurfaceReady(
            surfaceTexture: SurfaceTexture,
            bufferWidth: Int,
            bufferHeight: Int
        )
    }

    var listener: Listener? = null
        set(value) {
            field = value
            // Si el listener llega despues de onSurfaceCreated (la
            // GLSurfaceView arranca su hilo al inflar la vista), hay que
            // entregarle la textura ya creada.
            val st = surfaceTexture
            if (value != null && st != null) {
                value.onCameraSurfaceReady(st, bufferWidth, bufferHeight)
            }
        }

    /** Tamano del buffer de camara (lado sensor). */
    var bufferWidth: Int = 1280
        private set
    var bufferHeight: Int = 720
        private set

    /** Rotacion del sensor en grados (0, 90, 180, 270). */
    @Volatile
    var sensorOrientation: Int = 0

    private val rotated90: Boolean
        get() = sensorOrientation == 90 || sensorOrientation == 270

    val views = CopyOnWriteArrayList<ViewSpec>()

    private var nextId = 0
    fun nextId(): Int = nextId++

    private var frameAvailable = false

    private var oesProgram: GlProgram? = null
    private var solidProgram: GlProgram? = null

    private var oesTextureId = 0

    @Volatile
    private var surfaceTexture: SurfaceTexture? = null
    private val texMatrix = FloatArray(16)

    private val quadPosition: FloatBuffer = GlUtils.createFloatBuffer(
        floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
    )
    private val quadTexCoord: FloatBuffer = GlUtils.createFloatBuffer(FloatArray(8))

    private val mvp = FloatArray(16)
    private val identity = FloatArray(16)

    private var viewportW = 1
    private var viewportH = 1

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT

    private var fboId = 0
    private var fboTextureId = 0
    private var fboW = 0
    private var fboH = 0

    private var blitter: EncoderBlitter? = null
    private var recordStartNs = 0L

    @Volatile
    private var pendingSurface: Surface? = null

    @Volatile
    private var pendingWidth = 0

    @Volatile
    private var pendingHeight = 0

    @Volatile
    private var stopRequested = false

    @Volatile
    var isRecording: Boolean = false
        private set

    // ---------------------------------------------------------------------
    // API publica (llamable desde el hilo de UI)
    // ---------------------------------------------------------------------

    fun addView(spec: ViewSpec) {
        views.add(spec)
    }

    fun removeView(spec: ViewSpec) {
        views.remove(spec)
    }

    fun screenWidth(): Int = viewportW

    fun screenHeight(): Int = viewportH

    fun startRecording(encoderSurface: Surface, width: Int, height: Int) {
        pendingSurface = encoderSurface
        pendingWidth = width
        pendingHeight = height
    }

    fun stopRecording() {
        stopRequested = true
    }

    // ---------------------------------------------------------------------
    // GLSurfaceView.Renderer
    // ---------------------------------------------------------------------

    override fun onSurfaceCreated(gl: GL10?, config: JEGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)

        oesProgram = GlProgram(context, R.raw.vertex, R.raw.fragment_oes)
        solidProgram = GlProgram(context, R.raw.vertex_solid, R.raw.fragment_solid)

        Matrix.setIdentityM(texMatrix, 0)
        Matrix.setIdentityM(identity, 0)

        oesTextureId = GlUtils.createOesTexture()

        val st = SurfaceTexture(oesTextureId)
        st.setOnFrameAvailableListener(this)
        surfaceTexture = st

        eglDisplay = EGL14.eglGetCurrentDisplay()
        eglContext = EGL14.eglGetCurrentContext()

        listener?.onCameraSurfaceReady(st, bufferWidth, bufferHeight)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportW = width
        viewportH = height
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (frameAvailable) {
            try {
                surfaceTexture?.updateTexImage()
                surfaceTexture?.getTransformMatrix(texMatrix)
            } catch (e: Exception) {
                Log.w(TAG, "updateTexImage: ${e.message}")
            }
            frameAvailable = false
        }

        handlePendingRecording()

        // 1) Composicion hacia el FBO (destino del encoder)
        if (isRecording && fboId != 0) {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fboId)
            GLES20.glViewport(0, 0, fboW, fboH)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            drawComposite(fboW, fboH)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glFlush()
        }

        // 2) Composicion hacia la pantalla
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, viewportW, viewportH)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        drawComposite(viewportW, viewportH)

        // 3) Copia del FBO a la Surface del encoder
        if (isRecording && fboId != 0) {
            val pts = System.nanoTime() - recordStartNs
            blitter?.draw(fboTextureId, pts)
        }

        if (stopRequested) {
            stopRequested = false
            releaseRecording()
        }
    }

    override fun onFrameAvailable(st: SurfaceTexture) {
        frameAvailable = true
    }

    // ---------------------------------------------------------------------
    // Composicion
    // ---------------------------------------------------------------------

    private fun drawComposite(targetW: Int, targetH: Int) {
        val program = oesProgram ?: return
        val viewAspect = targetW.toFloat() / targetH.toFloat()

        program.use()

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTextureId)
        GLES20.glUniform1i(program.uTexture, 0)
        GLES20.glUniformMatrix4fv(program.uTexMatrix, 1, false, texMatrix, 0)

        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        // Fondo negro para las zonas sin cobertura (letterbox global)
        drawSolidRect(RectF(-1f, -1f, 1f, 1f), floatArrayOf(0f, 0f, 0f, 1f))

        for (view in views) {
            if (!view.visible) continue
            drawView(program, view, viewAspect, targetW, targetH)
        }

        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun drawView(
        program: GlProgram,
        view: ViewSpec,
        viewAspect: Float,
        targetW: Int,
        targetH: Int
    ) {
        val u0 = view.crop.left
        val u1 = view.crop.right
        val v0 = view.crop.top
        val v1 = view.crop.bottom

        val du = (u1 - u0).coerceAtLeast(0.0001f)
        val dv = (v1 - v0).coerceAtLeast(0.0001f)
        val bufferAspect = bufferWidth.toFloat() / bufferHeight.toFloat()
        val cropAspectBuffer = (du / dv) * bufferAspect
        val contentAspect = if (rotated90) 1f / cropAspectBuffer else cropAspectBuffer

        val dest = fitRect(view.dest, contentAspect, viewAspect, targetW, targetH)

        if (view.isPip) {
            val border = 0.012f
            drawSolidRect(
                RectF(
                    dest.left - border, dest.top - border,
                    dest.right + border, dest.bottom + border
                ),
                floatArrayOf(0f, 0f, 0f, 0.85f)
            )
        }

        // Esquinas en orden: BL, BR, TL, TR
        quadTexCoord.position(0)
        quadTexCoord.put(u0); quadTexCoord.put(v1)
        quadTexCoord.put(u1); quadTexCoord.put(v1)
        quadTexCoord.put(u0); quadTexCoord.put(v0)
        quadTexCoord.put(u1); quadTexCoord.put(v0)
        quadTexCoord.position(0)

        setQuadMvp(dest)

        // drawSolidRect pudo haber cambiado el programa activo, asi que
        // se vuelve a activar el de la camara y se re-suben sus uniformes.
        program.use()
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTextureId)

        GLES20.glUniformMatrix4fv(program.uMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(program.uTexMatrix, 1, false, texMatrix, 0)
        GLES20.glUniform1i(program.uTexture, 0)

        program.bindAttributes(quadPosition, quadTexCoord)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun drawSolidRect(rect: RectF, color: FloatArray) {
        val program = solidProgram ?: return
        program.use()

        setQuadMvp(rect)

        GLES20.glUniformMatrix4fv(program.uMVP, 1, false, mvp, 0)
        if (program.uColor >= 0) {
            GLES20.glUniform4fv(program.uColor, 1, color, 0)
        }

        program.bindAttributes(quadPosition, null)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    /**
     * Escribe en [mvp] la matriz que lleva el quad unitario al rect indicado.
     *
     * El rect viene en "NDC top-down": x e y en [-1, 1], con y creciendo
     * hacia abajo (igual que un RectF normal). GL usa y hacia arriba, asi
     * que se niega el centro vertical.
     */
    private fun setQuadMvp(rect: RectF) {
        val sx = rect.width() / 2f
        val sy = rect.height() / 2f
        val cx = rect.centerX()
        val cy = rect.centerY()

        Matrix.setIdentityM(mvp, 0)
        mvp[0] = sx
        mvp[5] = sy
        mvp[12] = cx
        mvp[13] = -cy
    }

    /**
     * Ajusta [dest] (NDC) para que el contenido de aspecto [contentAspect]
     * entre completo sin deformarse dentro de un viewport de aspecto
     * [viewAspect]. Centra el resultado.
     */
    private fun fitRect(
        dest: RectF,
        contentAspect: Float,
        viewAspect: Float,
        targetW: Int,
        targetH: Int
    ): RectF {
        val cx = dest.centerX()
        val cy = dest.centerY()

        var widthNdc = dest.width()
        var heightNdc = dest.height()

        // Convertimos a pixeles para comparar aspectos reales.
        val pxW = widthNdc / 2f * targetW
        val pxH = heightNdc / 2f * targetH
        val destAspect = pxW / pxH

        if (destAspect > contentAspect) {
            val newPxW = pxH * contentAspect
            widthNdc = newPxW / targetW * 2f
        } else {
            val newPxH = pxW / contentAspect
            heightNdc = newPxH / targetH * 2f
        }

        return RectF(
            cx - widthNdc / 2f,
            cy - heightNdc / 2f,
            cx + widthNdc / 2f,
            cy + heightNdc / 2f
        )
    }

    // ---------------------------------------------------------------------
    // Grabacion
    // ---------------------------------------------------------------------

    private fun handlePendingRecording() {
        val surface = pendingSurface ?: return
        pendingSurface = null

        if (pendingWidth <= 0 || pendingHeight <= 0) return

        fboW = pendingWidth
        fboH = pendingHeight

        createFbo(fboW, fboH)

        val b = EncoderBlitter(context, fboW, fboH)
        if (!b.start(eglContext, surface)) {
            Log.e(TAG, "No se pudo iniciar el blitter del encoder")
            destroyFbo()
            return
        }

        blitter = b
        recordStartNs = System.nanoTime()
        isRecording = true
        Log.i(TAG, "Grabacion iniciada a ${fboW}x$fboH")
    }

    private fun releaseRecording() {
        if (!isRecording && blitter == null) return

        isRecording = false

        blitter?.release()
        blitter = null

        destroyFbo()

        Log.i(TAG, "Grabacion detenida")
    }

    private fun createFbo(w: Int, h: Int) {
        destroyFbo()

        fboTextureId = GlUtils.createRgbTexture()
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, fboTextureId)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null
        )
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)

        val ids = IntArray(1)
        GLES20.glGenFramebuffers(1, ids, 0)
        fboId = ids[0]

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fboId)
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D, fboTextureId, 0
        )

        val status = GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER)
        if (status != GLES20.GL_FRAMEBUFFER_COMPLETE) {
            Log.e(TAG, "FBO incompleto: 0x${Integer.toHexString(status)}")
        }

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
    }

    private fun destroyFbo() {
        if (fboId != 0) {
            val ids = intArrayOf(fboId)
            GLES20.glDeleteFramebuffers(1, ids, 0)
            fboId = 0
        }
        if (fboTextureId != 0) {
            val ids = intArrayOf(fboTextureId)
            GLES20.glDeleteTextures(1, ids, 0)
            fboTextureId = 0
        }
    }
}
