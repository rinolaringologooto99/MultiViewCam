# MultiViewCam

Demo Android que reproduce, con una **implementación propia**, el esquema de
"multi-cámara con un solo teléfono" de apps tipo CameraFi Live:

- una única cámara (Camera2) como fuente de frames
- **N vistas virtuales** que muestran recortes/zoom distintos del mismo frame
- **ventana PiP arrastrable** con el dedo
- **cambiador de cámara** (trasera / frontal)
- **grabación local a `.mp4`** de la composición final

Todo el código es original. No se ha copiado nada del APK decompilado que se
usó solo como referencia de comportamiento.

---

## Requisitos

- Android Studio (Ladybug o superior) o Gradle 8.7 + JDK 17
- SDK de Android 34 instalado
- Dispositivo o emulador con cámara, **API 24+**
- Gradle Wrapper incluido: no hace falta instalar Gradle a mano

## Cómo compilarlo

### Opción A — Android Studio

1. `File > Open...` y selecciona la carpeta `MultiViewCam`.
2. Espera al *Gradle Sync* (descargará Gradle 8.7 y las dependencias).
3. `Run > Run 'app'`.

### Opción B — línea de comandos

```powershell
cd MultiViewCam
.\gradlew.bat assembleDebug
```

El APK queda en `app\build\outputs\apk\debug\app-debug.apk`.

Si Gradle se queja de que falta el SDK, crea `local.properties`:

```properties
sdk.dir=C\:\\Users\\TU_USUARIO\\AppData\\Local\\Android\\Sdk
```

---

## Uso

| Botón | Qué hace |
|---|---|
| **+ Vista** | Añade una vista virtual. Hasta 4 vistas principales, repartidas en rejilla. Cada una muestra una zona distinta del frame (zoom 1x, 2x, 2.5x, 3x). |
| **PiP** | Añade / quita una ventana flotante. Se puede **arrastrar** con el dedo. |
| **Cambiar** | Alterna cámara trasera ↔ frontal (cierra y reabre el `CameraDevice`). |
| **Grabar / Detener** | Graba la composición a `Películas/MultiViewCam/` (API 29+) o a la carpeta privada de la app (API 24-28). |

Al arrancar se pide el permiso de cámara. Sin él no se abre ningún preview.

---

## Arquitectura

```
Camera2Controller ──► SurfaceTexture (textura OES, 1 sola)
                            │
                            ▼
                   MultiViewRenderer (GL)
                     ├─ por cada ViewSpec:
                     │     crop (RectF 0..1 en espacio de textura)
                     │     dest (RectF en NDC "top-down")
                     │     aspect-fit por vista
                     ├─► framebuffer de pantalla (preview)
                     └─► FBO intermedio (1280x720)
                                │
                                ▼
                         EncoderBlitter
                    (contexto EGL secundario COMPARTIDO)
                                │
                                ▼
              MediaCodec H.264 (COLOR_FormatSurface)
                                │
                                ▼
                      MediaMuxer ──► .mp4
```

### Piezas

| Archivo | Responsabilidad |
|---|---|
| `camera/Camera2Controller.kt` | Abre/cierra `CameraDevice`, sesión de captura y `setRepeatingRequest`. El "switcher" es cerrar y reabrir con la otra lente. |
| `gl/MultiViewRenderer.kt` | Núcleo. Crea la textura OES y el `SurfaceTexture`, compone todas las vistas y gestiona el FBO. |
| `gl/EncoderBlitter.kt` | Contexto EGL secundario compartido; copia la textura del FBO a la `Surface` del encoder. |
| `gl/MultiViewSurfaceView.kt` | `GLSurfaceView` + arrastre del PiP (conversión px → NDC). |
| `model/ViewSpec.kt` | Una vista: rect destino, rect de recorte, flag PiP, zoom. |
| `recorder/VideoRecorder.kt` | `MediaCodec` (AVC) + `MediaMuxer`, hilo de drenado y destino en MediaStore. |
| `gl/GlProgram.kt`, `gl/GlUtils.kt` | Utilidades GLSL/GLES20. |

### Por qué un contexto EGL secundario

El preview lo dibuja `GLSurfaceView` en su propio contexto. Para grabar sin
duplicar la lógica de composición:

1. Se compone una vez a un **FBO** con textura 2D.
2. Se compone otra vez a la pantalla.
3. Un **segundo contexto EGL compartido** (comparte texturas con el primero)
   dibuja esa textura del FBO sobre la `Surface` de entrada del `MediaCodec`.

El contexto de preview se guarda y se restaura en cada cambio, para que
`GLSurfaceView` siga pudiendo hacer `eglSwapBuffers`.

### Convención de coordenadas

- `ViewSpec.dest`: NDC **top-down**, `x, y ∈ [-1, 1]`, `y` crece hacia abajo.
  Así el `RectF` es un rectángulo normal (`top < bottom`) y `contains()`
  funciona para el hit-testing del arrastre. La matriz del quad niega el
  centro vertical al pasar a GL (que usa `y` hacia arriba).
- `ViewSpec.crop`: coordenadas de textura `0..1` sobre el frame completo.

### Aspect ratio

`SurfaceTexture.getTransformMatrix()` aplica la rotación del sensor. El
aspecto del contenido se calcula con el tamaño del buffer **y** el
`sensorOrientation`: si el sensor está a 90°/270°, el aspecto mostrado es el
inverso. Cada vista hace *aspect-fit* dentro de su rect destino, de modo que
nunca se deforma la imagen.

---

## Limitaciones conocidas

- **La grabación es solo vídeo, sin audio.** Añadir audio requiere un
  `AudioRecord` + `MediaCodec` AAC y mezclar dos pistas en el `MediaMuxer`
  con sus timestamps. El `VideoRecorder` está preparado para ello (el muxer
  admite más pistas), pero no está implementado.
- La app está bloqueada en **vertical**.
- Máximo **4** vistas principales (más el PiP). El límite está en
  `MainActivity.MAX_MAIN_VIEWS`; subirlo es solo cambiar la constante, aunque
  la rejilla se vuelve muy pequeña.
- El cambio de cámara tarda un instante: hay que cerrar sesión y dispositivo
  antes de reabrir (es el mismo patrón de CameraFi, no hay dos cámaras
  abiertas a la vez).
- Si el dispositivo no expone `LENS_FACING_FRONT`, el botón de cambio avisa y
  no hace nada.

## Posibles siguientes pasos

1. Audio AAC en la grabación.
2. Gestos de pinch-to-zoom sobre cada vista (ya existe `ViewSpec.applyZoom`).
3. Reordenar vistas arrastrando (la lógica de arrastre del PiP es reutilizable).
4. Exportar a otras resoluciones / bitrates desde ajustes.
5. Guardar la composición (rects + crops) para reutilizarla al reabrir.
