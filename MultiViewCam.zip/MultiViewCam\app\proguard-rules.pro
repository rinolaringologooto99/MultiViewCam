# Reglas ProGuard del modulo :app
# No se aplica minificacion en debug.
-keep class com.example.multiviewcam.** { *; }
