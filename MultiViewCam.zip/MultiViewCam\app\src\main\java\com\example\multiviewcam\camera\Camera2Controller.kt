package com.example.multiviewcam.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import androidx.core.content.ContextCompat

/**
 * Controlador de una unica camara Camera2.
 *
 * El SurfaceTexture NO lo crea esta clase: lo crea el renderer (porque la
 * textura OES tiene que nacer en el hilo de GL) y lo entrega via
 * [MultiViewRenderer.Listener.onCameraSurfaceReady].
 *
 * Cambiar de camara = cerrar sesion y dispositivo, y reabrir con la otra
 * lente. Es exactamente el mismo patron que usa CameraFi Live para su
 * "switcher": no hay dos camaras abiertas a la vez.
 */
class Camera2Controller(private val context: Context) {

    companion object {
        private const val TAG = "Camera2Controller"
    }

    interface Callback {
        /** La camara ya esta entregando frames. */
        fun onCameraReady(sensorOrientation: Int)

        /** Algo fallo. [message] es apto para mostrar al usuario. */
        fun onCameraError(message: String)
    }

    var callback: Callback? = null

    private val manager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null

    private var surfaceTexture: SurfaceTexture? = null
    private var targetSurface: Surface? = null

    private var bufferWidth = 1280
    private var bufferHeight = 720

    private var facing = CameraCharacteristics.LENS_FACING_BACK

    /** Rotacion del sensor en grados. */
    var sensorOrientation: Int = 0
        private set

    val isOpen: Boolean
        get() = device != null

    var isUsingFrontCamera: Boolean = false
        private set

    // ------------------------------------------------------------------
    // API publica
    // ------------------------------------------------------------------

    /**
     * Abre la camara y empieza a escribir frames en [st].
     * Debe llamarse con el permiso CAMERA ya concedido.
     */
    fun open(st: SurfaceTexture, width: Int, height: Int) {
        surfaceTexture = st
        bufferWidth = width
        bufferHeight = height
        st.setDefaultBufferSize(width, height)

        startThread()
        handler?.post { openInternal() }
    }

    /** Alterna entre camara trasera y delantera. */
    fun switchCamera() {
        val wanted = if (facing == CameraCharacteristics.LENS_FACING_BACK) {
            CameraCharacteristics.LENS_FACING_FRONT
        } else {
            CameraCharacteristics.LENS_FACING_BACK
        }

        if (findCameraId(wanted) == null) {
            callback?.onCameraError("Este dispositivo no tiene esa camara")
            return
        }

        facing = wanted
        isUsingFrontCamera = wanted == CameraCharacteristics.LENS_FACING_FRONT

        handler?.post {
            closeSessionAndDevice()
            openInternal()
        }
    }

    /** Libera todo. Seguro de llamar varias veces. */
    fun close() {
        closeSessionAndDevice()
        releaseSurface()
        stopThread()
        surfaceTexture = null
    }

    // ------------------------------------------------------------------
    // Interno
    // ------------------------------------------------------------------

    private fun openInternal() {
        val st = surfaceTexture ?: return
        val id = findCameraId(facing)
        if (id == null) {
            callback?.onCameraError("No se encontro ninguna camara")
            return
        }

        sensorOrientation = try {
            manager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        } catch (e: Exception) {
            0
        }

        // La Surface vieja se libera: al cambiar de lente el buffer cambia.
        releaseSurface()
        targetSurface = Surface(st)

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            callback?.onCameraError("Falta el permiso de camara")
            return
        }

        try {
            @SuppressLint("MissingPermission")
            manager.openCamera(id, deviceCallback, handler)
        } catch (e: Exception) {
            Log.e(TAG, "openCamera", e)
            callback?.onCameraError("No se pudo abrir la camara: ${e.message}")
        }
    }

    private val deviceCallback = object : CameraDevice.StateCallback() {

        override fun onOpened(camera: CameraDevice) {
            device = camera
            createSession(camera)
        }

        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            if (device === camera) device = null
        }

        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            if (device === camera) device = null
            callback?.onCameraError("Error de camara ($error)")
        }
    }

    private fun createSession(camera: CameraDevice) {
        val surface = targetSurface ?: return

        try {
            val request = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
            }.build()

            @Suppress("DEPRECATION")
            camera.createCaptureSession(
                listOf(surface),
                object : CameraCaptureSession.StateCallback() {

                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        try {
                            s.setRepeatingRequest(request, null, handler)
                            callback?.onCameraReady(sensorOrientation)
                        } catch (e: Exception) {
                            Log.e(TAG, "setRepeatingRequest", e)
                            callback?.onCameraError("No se pudo iniciar el preview")
                        }
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        callback?.onCameraError("No se pudo configurar la sesion de captura")
                    }
                },
                handler
            )
        } catch (e: Exception) {
            Log.e(TAG, "createCaptureSession", e)
            callback?.onCameraError("No se pudo crear la sesion de captura: ${e.message}")
        }
    }

    private fun closeSessionAndDevice() {
        try {
            session?.stopRepeating()
        } catch (e: Exception) {
            // ignorado
        }
        try {
            session?.close()
        } catch (e: Exception) {
            // ignorado
        }
        session = null

        try {
            device?.close()
        } catch (e: Exception) {
            // ignorado
        }
        device = null
    }

    private fun releaseSurface() {
        try {
            targetSurface?.release()
        } catch (e: Exception) {
            // ignorado
        }
        targetSurface = null
    }

    private fun startThread() {
        if (thread != null) return
        val t = HandlerThread("Camera2Thread")
        t.start()
        thread = t
        handler = Handler(t.looper)
    }

    private fun stopThread() {
        val t = thread ?: return
        thread = null
        handler = null
        t.quitSafely()
        try {
            t.join(1500)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun findCameraId(lensFacing: Int): String? {
        return try {
            manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.LENS_FACING) == lensFacing
            }
        } catch (e: Exception) {
            Log.e(TAG, "cameraIdList", e)
            null
        }
    }
}
