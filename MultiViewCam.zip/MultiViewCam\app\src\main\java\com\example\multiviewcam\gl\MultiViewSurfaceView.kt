package com.example.multiviewcam.gl

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.MotionEvent
import com.example.multiviewcam.model.ViewSpec

/**
 * GLSurfaceView que ademas gestiona el arrastre de la ventana PiP.
 */
class MultiViewSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    val mvRenderer = MultiViewRenderer(context)

    /** Desplazamiento entre el centro del PiP y el punto tocado (NDC). */
    private var grabOffsetX = 0f
    private var grabOffsetY = 0f
    private var dragging: ViewSpec? = null

    init {
        setEGLContextClientVersion(2)
        setPreserveEGLContextOnPause(true)
        setRenderer(mvRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        isFocusable = true
        isClickable = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val pip = mvRenderer.views.lastOrNull { it.isPip && it.visible }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (pip == null) return false
                val nx = pxToNdcX(event.x)
                val ny = pxToNdcY(event.y)
                if (!pip.dest.contains(nx, ny)) return false

                dragging = pip
                grabOffsetX = nx - pip.dest.centerX()
                grabOffsetY = ny - pip.dest.centerY()
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val target = dragging ?: return false
                val nx = pxToNdcX(event.x)
                val ny = pxToNdcY(event.y)
                moveRectTo(target.dest, nx - grabOffsetX, ny - grabOffsetY)
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = null
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun moveRectTo(rect: android.graphics.RectF, centerX: Float, centerY: Float) {
        val halfW = rect.width() / 2f
        val halfH = rect.height() / 2f

        val cx = centerX.coerceIn(-1f + halfW, 1f - halfW)
        val cy = centerY.coerceIn(-1f + halfH, 1f - halfH)

        rect.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH)
    }

    private fun pxToNdcX(px: Float): Float = (px / width.coerceAtLeast(1)) * 2f - 1f

    /** NDC con el eje Y hacia abajo (igual que el espacio de los RectF). */
    private fun pxToNdcY(py: Float): Float = (py / height.coerceAtLeast(1)) * 2f - 1f

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
