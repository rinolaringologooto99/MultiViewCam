package com.example.multiviewcam.model

import android.graphics.RectF

/**
 * Una "vista virtual": un recuadro en pantalla que muestra una region
 * concreta (crop) del mismo frame de camara.
 *
 * No abre una camara adicional: reutiliza la unica SurfaceTexture.
 *
 * Coordenadas:
 *  - [dest] se expresa en "NDC top-down": x e y en [-1, 1],
 *    y creciendo hacia ABAJO (como un RectF normal).
 *    left/top = -1,-1 es la esquina superior izquierda.
 *  - [crop] se expresa en coordenadas de textura 0..1
 *    (left, top, right, bottom) sobre el frame completo.
 */
data class ViewSpec(
    val id: Int,
    /** Rectangulo destino en NDC. */
    var dest: RectF,
    /** Region de la textura que se muestra (0..1). */
    var crop: RectF,
    /** Si esta vista se comporta como ventana PiP (arrastrable). */
    var isPip: Boolean = false,
    var visible: Boolean = true
) {
    fun resetCrop() {
        crop.set(0f, 0f, 1f, 1f)
    }

    /** Aplica un zoom centrado. zoom = 1 -> sin recorte; zoom = 2 -> mitad del frame. */
    fun applyZoom(zoom: Float, centerU: Float = 0.5f, centerV: Float = 0.5f) {
        val half = 0.5f / zoom.coerceAtLeast(1f)
        val left = (centerU - half).coerceIn(0f, 1f - 2f * half)
        val top = (centerV - half).coerceIn(0f, 1f - 2f * half)
        crop.set(left, top, left + 2f * half, top + 2f * half)
    }
}
