package com.example.multiviewcam.gl

import android.content.Context
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.Matrix
import android.util.Log
import android.view.Surface
import com.example.multiviewcam.R
import java.nio.FloatBuffer

/**
 * Contexto EGL secundario (compartido con el contexto de preview) que
 * dibuja la textura 2D compuesta sobre la Surface de entrada del encoder.
 *
 * Es el equivalente propio de lo que en la app analizada hacia el sink
 * del compositor: renderizar el mismo cuadro al encoder ademas de a la
 * pantalla.
 */
class EncoderBlitter(
    private val context: Context,
    private val width: Int,
    private val height: Int
) {

    private companion object {
        const val TAG = "EncoderBlitter"
    }

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var config: EGLConfig? = null

    private var program: GlProgram? = null

    private val position: FloatBuffer = GlUtils.createFloatBuffer(
        floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
    )
    private val texCoord: FloatBuffer = GlUtils.createFloatBuffer(
        floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f)
    )

    private val mvp = FloatArray(16)
    private val identity = FloatArray(16)

    var isReady = false
        private set

    fun start(sharedContext: EGLContext, encoderSurface: Surface): Boolean {
        val prevDisplay = EGL14.eglGetCurrentDisplay()
        val prevDraw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
        val prevRead = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
        val prevContext = EGL14.eglGetCurrentContext()

        val ok = tryStart(sharedContext, encoderSurface)

        // Devolvemos el contexto de preview, que es el que estaba activo
        // cuando nos llamaron desde onDrawFrame.
        if (prevContext != EGL14.EGL_NO_CONTEXT) {
            EGL14.eglMakeCurrent(prevDisplay, prevDraw, prevRead, prevContext)
        }

        return ok
    }

    private fun tryStart(sharedContext: EGLContext, encoderSurface: Surface): Boolean {
        display = EGL14.eglGetCurrentDisplay()
        if (display == EGL14.EGL_NO_DISPLAY) {
            Log.e(TAG, "No hay display EGL actual")
            return false
        }

        config = chooseConfig(display)
        if (config == null) {
            Log.e(TAG, "No se encontro EGLConfig compatible")
            return false
        }

        val ctxAttribs = intArrayOf(
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
        )
        eglContext = EGL14.eglCreateContext(display, config, sharedContext, ctxAttribs, 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) {
            Log.e(TAG, "eglCreateContext fallo: 0x${Integer.toHexString(EGL14.eglGetError())}")
            return false
        }

        val surfAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(display, config, encoderSurface, surfAttribs, 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) {
            Log.e(TAG, "eglCreateWindowSurface fallo: 0x${Integer.toHexString(EGL14.eglGetError())}")
            return false
        }

        if (!EGL14.eglMakeCurrent(display, eglSurface, eglSurface, eglContext)) {
            Log.e(TAG, "eglMakeCurrent fallo: 0x${Integer.toHexString(EGL14.eglGetError())}")
            return false
        }

        program = GlProgram(context, R.raw.vertex, R.raw.fragment_2d)
        Matrix.setIdentityM(mvp, 0)
        Matrix.setIdentityM(identity, 0)

        GLES20.glDisable(GLES20.GL_BLEND)

        isReady = true
        Log.i(TAG, "Blitter listo ${width}x$height")
        return true
    }

    fun draw(textureId: Int, presentationTimeNs: Long) {
        val prog = program
        if (!isReady || prog == null) return

        val prevDisplay = EGL14.eglGetCurrentDisplay()
        val prevDraw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
        val prevRead = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
        val prevContext = EGL14.eglGetCurrentContext()

        if (!EGL14.eglMakeCurrent(display, eglSurface, eglSurface, eglContext)) {
            Log.e(TAG, "eglMakeCurrent (draw) fallo")
            return
        }

        GLES20.glViewport(0, 0, width, height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        prog.use()
        GLES20.glUniformMatrix4fv(prog.uMVP, 1, false, mvp, 0)
        if (prog.uTexMatrix >= 0) {
            GLES20.glUniformMatrix4fv(prog.uTexMatrix, 1, false, identity, 0)
        }

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glUniform1i(prog.uTexture, 0)

        prog.bindAttributes(position, texCoord)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        EGLExt.eglPresentationTimeANDROID(display, eglSurface, presentationTimeNs)
        EGL14.eglSwapBuffers(display, eglSurface)

        EGL14.eglMakeCurrent(prevDisplay, prevDraw, prevRead, prevContext)
    }

    fun release() {
        val prevDisplay = EGL14.eglGetCurrentDisplay()
        val prevDraw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
        val prevRead = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
        val prevContext = EGL14.eglGetCurrentContext()

        isReady = false

        // El programa hay que borrarlo con el contexto del blitter activo.
        if (display != EGL14.EGL_NO_DISPLAY && eglContext != EGL14.EGL_NO_CONTEXT) {
            if (EGL14.eglMakeCurrent(display, eglSurface, eglSurface, eglContext)) {
                program?.release()
            }
        }
        program = null

        if (display != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(
                display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT
            )
            if (eglSurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(display, eglSurface)
            }
            if (eglContext != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglDestroyContext(display, eglContext)
            }
        }

        eglSurface = EGL14.EGL_NO_SURFACE
        eglContext = EGL14.EGL_NO_CONTEXT
        display = EGL14.EGL_NO_DISPLAY
        config = null

        // Restauramos el contexto de preview para no romper el swap de
        // la GLSurfaceView en el siguiente frame.
        if (prevContext != EGL14.EGL_NO_CONTEXT) {
            EGL14.eglMakeCurrent(prevDisplay, prevDraw, prevRead, prevContext)
        }
    }

    private fun chooseConfig(display: EGLDisplay): EGLConfig? {
        val attribs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val count = IntArray(1)
        val ok = EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, count, 0)
        return if (ok && count[0] > 0) configs[0] else null
    }
}
